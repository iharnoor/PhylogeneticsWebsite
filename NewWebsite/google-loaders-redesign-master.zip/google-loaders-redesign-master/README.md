# Google Loaders Redesign
A collection of Google loaders in a new look, [Live Demo Here](https://mohamedbahmed.gitlab.io/google-loaders-redesign/)  

![Google Loaders Redesign](Gloaders.gif)

Developed By [Amine Bahmed](https://twitter.com/Amin_Bahmed)  
View Project on [Uplabs](https://www.uplabs.com/aminebahmed) & [CodePen](https://codepen.io/AmineMohamed/full/JZxyYm/)